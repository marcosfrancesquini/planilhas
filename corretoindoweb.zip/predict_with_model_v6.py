#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
predict_with_model_v6.py
---------------------------------
Mesma base da v5, porém com um preset pronto: --preset combo_refined
que aplica automaticamente um conjunto de parâmetros afinado para
equilibrar acerto alto com presença em 0–29 (sem precisar passar mil flags).

Uso típico:
  python predict_with_model_v6.py --predict planilha.xlsx --model model.pkl --topk 50 --preset combo_refined

Dica: se quiser manter sua "faixa dourada", use também --normalize-rows 2200
"""

import argparse, pickle, unicodedata
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np, pandas as pd

# ---------------- Utils ----------------
def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", str(s)) if unicodedata.category(c) != "Mn")

def norm_text(s) -> str:
    return strip_accents(str(s)).lower().strip()

def looks_numeric_0_99(series: pd.Series, threshold=0.30) -> bool:
    vals = 0; ok = 0
    for x in series.dropna().astype(str).tolist():
        vals += 1
        try:
            v = int(float(x.strip()))
            if 0 <= v <= 99: ok += 1
        except: pass
    return vals>0 and (ok/vals)>=threshold

def decil_of_row(ridx: int, nrows: int, normalize_to: int|None=None) -> int:
    if nrows <= 0:
        return 1
    base = ridx + 1
    if normalize_to and normalize_to > 0:
        frac = base / nrows
        virtual = int(np.ceil(frac * normalize_to))
        return max(1, min(10, int(np.ceil(virtual / normalize_to * 10))))
    return int(np.ceil(base / nrows * 10))

# ---------------- Blocos ----------------
def find_block_starts(df: pd.DataFrame):
    starts = []
    for idx, row in df.astype(str).iterrows():
        row_norm = [norm_text(x) for x in row.values]
        has_nb = any(("numero base" in x) or ("número base" in x) or ("numero" in x and "base" in x) for x in row_norm)
        has_core = any(
            ("maxima" in x and "freq" in x and "complet" in x) or
            ("minima" in x and "freq" in x and "complet" in x) or
            ("frequencia" in x and "ultimo" in x)
            for x in row_norm
        )
        if has_nb or has_core:
            starts.append(idx)
    return starts

def build_block(df: pd.DataFrame, start_idx: int, end_idx: int) -> pd.DataFrame:
    header_vals = [str(x).strip() if pd.notna(x) else "" for x in df.iloc[start_idx].tolist()]
    data = df.iloc[start_idx + 1:end_idx].copy().dropna(axis=1, how="all")
    if data.shape[1] == 0:
        return pd.DataFrame()
    headers = header_vals[:len(data.columns)]
    if len(headers) < len(data.columns):
        headers += [f"col_{i}" for i in range(len(headers), len(data.columns))]
    uniq, counts = [], {}
    for h in headers:
        key = h if h else "col"
        if key in counts: counts[key] += 1; uniq.append(f"{key}_{counts[key]}")
        else: counts[key] = 0; uniq.append(key)
    data.columns = uniq
    return data.dropna(how="all").reset_index(drop=True)

def extract_blocks(df: pd.DataFrame):
    starts = find_block_starts(df)
    blocks = []
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else len(df)
        b = build_block(df, s, e)
        if not b.empty: blocks.append(b)
    if not blocks:
        data = df.dropna(axis=1, how="all").reset_index(drop=True).copy()
        if data.shape[1] == 0:
            return []
        data.columns = [f"col_{i}" for i in range(len(data.columns))]
        blocks = [data]
    return blocks

# ---------------- Colunas ----------------
def match_columns(block_df: pd.DataFrame, col_reliability: dict, force_cols=None, force_smart=False):
    cols = block_df.columns.tolist()
    norm_cols = {c: norm_text(c) for c in cols}

    if force_cols:
        targets = [norm_text(x) for x in force_cols]
        matched = [c for c in cols if any(t in norm_cols[c] for t in targets)]
        if matched: return matched

    model_keys_norm = {norm_text(k): v for k, v in col_reliability.items()}
    direct = [c for c in cols if norm_cols[c] in model_keys_norm]
    if direct: return direct

    aliases = [
        ["maxima","freq","blocos","completos"],
        ["minima","freq","blocos","completos"],
        ["frequencia","ultimo","bloco","incompleto"],
        ["numero"]
    ]
    alias_match = []
    for c in cols:
        nc = norm_cols[c]
        for words in aliases:
            if all(w in nc for w in words):
                alias_match.append(c); break
    if alias_match: return alias_match

    if force_smart:
        smart = [c for c in cols if looks_numeric_0_99(block_df[c], threshold=0.30)]
        if smart: return smart

    return []

# ---------------- Scoring ----------------
BASE_DECIL_WEIGHTS = np.array([1.00, -0.40, 0.10, 0.35, 0.30, 0.30, 0.10, 0.15, 0.60, -0.25], dtype=float)

def normalize01(x: np.ndarray) -> np.ndarray:
    if x.size == 0: return x
    mn, mx = x.min(), x.max()
    return (x - mn) / (mx - mn + 1e-9)

def compute_scores_for_block(b: pd.DataFrame, dec_prior, col_rel, alpha=0.6,
                             normalize_rows=None, use_cols=None, force_all_if_none=True,
                             early_decile_gain=0.0, low_rarity_boost=0.0):
    value_scores = defaultdict(float)
    cols_for_presence = match_columns(b, col_rel, force_cols=use_cols, force_smart=(use_cols is None))
    use_all = False
    if not cols_for_presence and force_all_if_none:
        use_all = True

    rarity_map = {}
    if low_rarity_boost > 0.0:
        for col in (cols_for_presence if cols_for_presence else b.columns):
            try:
                vals = b[col].dropna().astype(int)
                vals = vals[(vals>=0) & (vals<=99)]
                cnt = Counter(vals.tolist())
                rarity_map[col] = {v: 1.0/(c+1.0) for v, c in cnt.items()}
            except Exception:
                continue

    n = len(b)
    w_norm = normalize01(BASE_DECIL_WEIGHTS)
    for ridx in range(n):
        dec = decil_of_row(ridx, n, normalize_rows) - 1
        base_line = float(dec_prior[dec] * w_norm[dec])
        present_boost = 0.0
        if cols_for_presence:
            for col in cols_for_presence:
                if col in b.columns and pd.notna(b.iloc[ridx][col]):
                    present_boost += col_rel.get(norm_text(col), 0.0)
        row_score = base_line * (1.0 + alpha * present_boost)

        if early_decile_gain > 0 and dec in (0,1,2):
            row_score *= (1.0 + early_decile_gain)

        use_cols_vals = b.columns if use_all else (cols_for_presence if cols_for_presence else b.columns)
        for col in use_cols_vals:
            val = b.iloc[ridx][col]
            if pd.isna(val): continue
            try:
                v = int(float(str(val).strip()))
            except:
                continue
            if 0 <= v <= 99:
                extra = 0.0
                if low_rarity_boost > 0.0 and v <= 29 and col in rarity_map:
                    extra += low_rarity_boost * rarity_map[col].get(v, 0.0)
                value_scores[v] += row_score + extra

    return value_scores

def ensemble_scores(blocks, dec_prior, col_rel, alpha=0.6,
                    normalize_rows=None, presets=("balanced","high15","combo_vintage","spread"),
                    early_decile_gain=0.0, low_rarity_boost=0.0):
    preset_params = {
        "balanced":      dict(alpha=alpha, early=0.10, rarity=0.05),
        "high15":        dict(alpha=alpha, early=0.05, rarity=0.00),
        "combo_vintage": dict(alpha=alpha, early=early_decile_gain, rarity=low_rarity_boost),
        "spread":        dict(alpha=alpha*0.9, early=0.20, rarity=0.08),
    }
    total = defaultdict(float)
    for pname in presets:
        pp = preset_params.get(pname.strip(), preset_params["balanced"])
        for b in blocks:
            sc = compute_scores_for_block(b, dec_prior, col_rel,
                                          alpha=pp["alpha"],
                                          normalize_rows=normalize_rows,
                                          use_cols=None,
                                          force_all_if_none=True,
                                          early_decile_gain=pp["early"],
                                          low_rarity_boost=pp["rarity"])
            for k, v in sc.items():
                total[k] += v
    return total

# ---------------- Seleção ----------------
def select_stratified(df_rank, topk=50,
                      low_min=6, low_cap=8,
                      mid_min=8, mid_cap=12,
                      high_cap=34,
                      min_gap_low=2,
                      anti_high=0.0, neighbor_radius=2):
    df = df_rank.sort_values(["score", "valor"], ascending=[False, True]).reset_index(drop=True)

    def bucket(v):
        return "low" if v <= 29 else "mid" if v <= 59 else "high"

    sel, lows = [], []
    counts = {"low":0, "mid":0, "high":0}

    # 1) mínimos
    for _, row in df.iterrows():
        if len(sel) >= topk: break
        v, b = int(row.valor), bucket(int(row.valor))
        if b == "low" and counts["low"] < low_min:
            if all(abs(v - x) >= min_gap_low for x in lows):
                sel.append(v); lows.append(v); counts["low"] += 1

    for _, row in df.iterrows():
        if len(sel) >= topk: break
        v, b = int(row.valor), bucket(int(row.valor))
        if b == "mid" and counts["mid"] < mid_min and v not in sel:
            sel.append(v); counts["mid"] += 1

    # 2) completa respeitando caps + anti-high
    selected_set = set(sel)
    for _, row in df.iterrows():
        if len(sel) >= topk: break
        v, b = int(row.valor), bucket(int(row.valor))
        if v in selected_set: continue
        if b == "low" and counts["low"] >= low_cap: continue
        if b == "mid" and counts["mid"] >= mid_cap: continue
        if b == "high" and counts["high"] >= high_cap: continue

        if anti_high > 0 and b == "high":
            if any((x >= 80 and abs(x - v) <= neighbor_radius) for x in selected_set):
                continue

        if b == "low" and not all(abs(v - x) >= min_gap_low for x in lows):
            continue

        sel.append(v); selected_set.add(v)
        if b == "low": lows.append(v)
        counts[b] += 1

    # 3) completa por score puro
    if len(sel) < topk:
        for _, row in df.iterrows():
            v = int(row.valor)
            if v not in selected_set:
                sel.append(v); selected_set.add(v)
                if len(sel) >= topk: break

    return sel[:topk]

# ---------------- Main ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predict", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--topk", type=int, default=50)
    ap.add_argument("--preset", default="combo_refined",
                    choices=["balanced","high15","combo_vintage","spread","combo_refined"])
    ap.add_argument("--ensemble", default="")
    ap.add_argument("--normalize-rows", type=int, default=0)
    # Estratificação (defaults pensados para combo_refined)
    ap.add_argument("--low-min", type=int, default=6)
    ap.add_argument("--low-cap", type=int, default=8)
    ap.add_argument("--mid-min", type=int, default=8)
    ap.add_argument("--mid-cap", type=int, default=12)
    ap.add_argument("--high-cap", type=int, default=34)
    ap.add_argument("--min-gap-low", type=int, default=2)
    # Ganhos/penalizações (defaults combo_refined)
    ap.add_argument("--early-decile-gain", type=float, default=0.25)
    ap.add_argument("--low-rarity-boost", type=float, default=0.10)
    ap.add_argument("--anti-high", type=float, default=0.05)
    ap.add_argument("--neighbor-radius", type=int, default=2)
    args = ap.parse_args()

    # Se preset == combo_refined e o usuário não passou ensemble,
    # deixamos os defaults já afinados; se escolher outro preset,
    # o usuário pode ajustar manualmente pelas flags.
    preset_tag = args.preset
    if args.preset == "combo_refined" and not args.ensemble.strip():
        # mantém os defaults definidos no argparse (já estão afinados)
        pass

    # Carrega modelo
    with open(args.model, "rb") as f:
        model_dict = pickle.load(f)
    dec_prior = np.array(model_dict.get("dec_prior", np.zeros(10)), dtype=float)
    if dec_prior.shape[0] != 10:
        w = np.array([1.00, -0.40, 0.10, 0.35, 0.30, 0.30, 0.10, 0.15, 0.60, -0.25], dtype=float)
        w = (w - w.min())
        dec_prior = (w / (w.max() or 1.0))

    col_rel = {norm_text(k): float(v) for k, v in model_dict.get("col_reliability", {}).items()}

    # Lê primeira aba e extrai blocos
    df_all = pd.read_excel(args.predict, sheet_name=None)
    df = df_all[list(df_all.keys())[0]] if isinstance(df_all, dict) else df_all
    blocks = extract_blocks(df)
    if not blocks:
        raise RuntimeError("Nenhum bloco/dados aproveitáveis encontrados.")

    norm_rows = args.normalize_rows if args.normalize_rows > 0 else None

    if args.ensemble.strip():
        presets = [p.strip() for p in args.ensemble.split(",") if p.strip()]
        raw_scores = ensemble_scores(blocks, dec_prior, col_rel,
                                     alpha=0.6, normalize_rows=norm_rows,
                                     presets=presets,
                                     early_decile_gain=args.early_decile_gain,
                                     low_rarity_boost=args.low_rarity_boost)
        tag = "ensemble"
    else:
        raw_scores = defaultdict(float)
        for b in blocks:
            sc = compute_scores_for_block(b, dec_prior, col_rel, alpha=0.6,
                                          normalize_rows=norm_rows,
                                          use_cols=None, force_all_if_none=True,
                                          early_decile_gain=args.early_decile_gain,
                                          low_rarity_boost=args.low_rarity_boost)
            for k, v in sc.items():
                raw_scores[k] += v
        tag = preset_tag

    items = [{"valor": v, "score": s} for v, s in raw_scores.items()]
    df_rank = pd.DataFrame(items).sort_values(["score","valor"], ascending=[False,True]).reset_index(drop=True)

    nums = select_stratified(df_rank, topk=args.topk,
                             low_min=args.low_min, low_cap=args.low_cap,
                             mid_min=args.mid_min, mid_cap=args.mid_cap,
                             high_cap=args.high_cap,
                             min_gap_low=args.min_gap_low,
                             anti_high=args.anti_high, neighbor_radius=args.neighbor_radius)

    base = Path(args.predict).stem
    outdir = Path("out_predict"); outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / f"{base}_top{args.topk}_{tag}.csv"
    pd.DataFrame({"valor": nums}).to_csv(outpath, index=False, encoding="utf-8")

    print(f"[diag] {args.predict}: blocos = {len(blocks)}")
    print(f">>> {base} [{tag}|top{args.topk}]: {', '.join(map(str, nums))}")
    print(f"[ok] salvo em: {outpath}")

if __name__ == "__main__":
    main()
