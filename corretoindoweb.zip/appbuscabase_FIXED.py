marcos@marcos-HP-EliteBook-850-G5 correto$ python3 app_nove.py ordenado2111.xlsx

Arquivo: ordenado2111.xlsx
Parâmetros detectados: {'tamanho_bloco': 16, 'ultimo_bloco': 15, 'pct_faltante': 6.25, 'linhas_faltantes': 1, 'K': 16}

=== Lista final (25) — voto entre variações ===
[50, 49, 51, 48, 52, 47, 53, 46, 54, 45, 55, 44, 56, 43, 57, 42, 58, 41, 59, 40, 60, 39, 61, 38, 62]
marcos@marcos-HP-EliteBook-850-G5 correto$ python3 app_nove.py ordenado2099.xlsx

Arquivo: ordenado2099.xlsx
Parâmetros detectados: {'tamanho_bloco': 15, 'ultimo_bloco': 14, 'pct_faltante': 6.67, 'linhas_faltantes': 1, 'K': 15}

=== Lista final (25) — voto entre variações ===
[50, 49, 51, 48, 52, 47, 53, 46, 54, 45, 55, 44, 56, 43, 57, 42, 58, 41, 59, 40, 60, 39, 61, 38, 62]
marcos@marcos-HP-EliteBook-850-G5 correto$ python3 app_nove.py ordenado2101.xlsx

Arquivo: ordenado2101.xlsx
Parâmetros detectados: {'tamanho_bloco': 78, 'ultimo_bloco': 73, 'pct_faltante': 6.41, 'linhas_faltantes': 5, 'K': 78}

=== Lista final (25) — voto entre variações ===
[50, 49, 51, 48, 52, 47, 53, 46, 54, 45, 55, 44, 56, 43, 57, 42, 58, 41, 59, 40, 60, 39, 61, 38, 62]
marcos@marcos-HP-EliteBook-850-G5 correto$ python3 app_nove.py ordenado2107.xlsx

Arquivo: ordenado2107.xlsx
Parâmetros detectados: {'tamanho_bloco': 17, 'ultimo_bloco': 16, 'pct_faltante': 5.88, 'linhas_faltantes': 1, 'K': 17}

=== Lista final (25) — voto entre variações ===
[50, 49, 51, 48, 52, 47, 53, 46, 54, 45, 55, 44, 56, 43, 57, 42, 58, 41, 59, 40, 60, 39, 61, 38, 62]
marcos@marcos-HP-EliteBook-850-G5 correto$ 
