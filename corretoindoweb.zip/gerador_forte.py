import argparse
import re
from glob import glob
from typing import List, Tuple, Dict, Optional
import numpy as np
import pandas as pd

# ----------------------------- util de leitura/parse -----------------------------
def read_sheet(path: str) -> pd.DataFrame:
    return pd.read_excel(path, header=None, engine="openpyxl")

def parse_parameters(df: pd.DataFrame) -> Dict[str, Optional[float]]:
    text = " ".join([str(x) for x in df.iloc[:3, :10].fillna("").values.ravel().tolist()])
    params: Dict[str, Optional[float]] = {}
    m = re.search(r"Tamanho do bloco[:\s]*([0-9]+)", text, re.I)
    if m: params["tamanho_bloco"] = int(m.group(1))
    m = re.search(r"(Tamanho do (?:último|ultimo) bloco)[:\s]*([0-9]+)", text, re.I)
    if m: params["ultimo_bloco"] = int(m.group(2))
    m = re.search(r"(%|Porcentagem)\s*Faltante[:\s]*([0-9]+(?:[.,][0-9]+)?)", text, re.I)
    if m: params["pct_faltante"] = float(m.group(2).replace(",", "."))
    m = re.search(r"n[úu]mero de linhas faltantes[:\s]*([0-9]+)", text, re.I)
    if m: params["linhas_faltantes"] = int(m.group(1))
    m = re.search(r"K\s*=\s*([0-9]+)", text, re.I)
    if m: params["K"] = int(m.group(1))
    return params

def detect_base_columns(df: pd.DataFrame) -> List[Tuple[str,int,int]]:
    header_lines = 3
    pairs = []
    for col in range(df.shape[1]):
        col_text = " ".join([str(x) for x in df.iloc[:header_lines, col].fillna("").tolist()]).lower()
        if "numero base" in col_text or "número base" in col_text:
            base_idx = col
            metric_idx = max(0, col-1)
            metric_text = " ".join([str(x) for x in df.iloc[:header_lines, metric_idx].fillna("").tolist()]).strip()
            metric_text = re.sub(r"\s*\bnumero base\b.*", "", metric_text, flags=re.I)
            metric_text = re.sub(r"\s+", " ", metric_text).strip() or f"col_{metric_idx}"
            pairs.append((metric_text, metric_idx, base_idx))
    return pairs

def first_data_row(df: pd.DataFrame) -> int:
    for r in range(0, min(30, len(df))):
        nums = pd.to_numeric(df.iloc[r, :], errors='coerce')
        if np.isfinite(nums).sum() >= 2:
            return r
    return 2

# ----------------------------- montar base de treino -----------------------------
def build_base_dataframe(train_glob: str) -> pd.DataFrame:
    paths = sorted(glob(train_glob))
    if not paths:
        raise FileNotFoundError(f"Nenhum arquivo encontrado para: {train_glob}")
    rows = []
    for path in paths:
        df = read_sheet(path)
        params = parse_parameters(df)
        pairs = detect_base_columns(df)
        start = first_data_row(df)
        for _, _, base_idx in pairs:
            base_series = pd.to_numeric(df.iloc[start:, base_idx], errors='coerce')
            for i, val in enumerate(base_series, start=1):
                if pd.notna(val):
                    try:
                        ival = int(val)
                    except:
                        continue
                    rows.append({
                        "arquivo": path.split("/")[-1],
                        "valor": ival,
                        "pos": i,
                        "linhas_faltantes": params.get("linhas_faltantes", None)
                    })
    base_df = pd.DataFrame(rows).query("valor>=1 and valor<=99")
    if base_df.empty:
        raise ValueError("Base de treino vazia (valores 1..99).")
    return base_df

# ----------------------------- scoring -----------------------------
def _freq(series: pd.Series) -> pd.Series:
    vc = series.value_counts()
    vc.sort_index(inplace=True)
    return vc

def _norm(s: pd.Series) -> pd.Series:
    if len(s)==0:
        return pd.Series(dtype=float)
    s = s.astype(float)
    mx, mn = s.max(), s.min()
    if mx > mn:
        return (s - mn) / (mx - mn)
    return s / (mx if mx != 0 else 1.0)

def score_numbers(base_df: pd.DataFrame) -> pd.DataFrame:
    idx = sorted(base_df["valor"].unique().tolist())
    # globais
    freq_g   = _freq(base_df["valor"])
    freq_t15 = _freq(base_df.query("pos<=15")["valor"])
    freq_t20 = _freq(base_df.query("pos<=20")["valor"])
    freq_t25 = _freq(base_df.query("pos<=25")["valor"])
    # LF=1
    lf1 = base_df.query("linhas_faltantes==1")
    freq_g1    = _freq(lf1["valor"]) if len(lf1) else pd.Series(dtype=int)
    freq_t15_1 = _freq(lf1.query("pos<=15")["valor"]) if len(lf1) else pd.Series(dtype=int)
    freq_t20_1 = _freq(lf1.query("pos<=20")["valor"]) if len(lf1) else pd.Series(dtype=int)
    freq_t25_1 = _freq(lf1.query("pos<=25")["valor"]) if len(lf1) else pd.Series(dtype=int)

    Sg   = _norm(freq_g).reindex(idx).fillna(0.0)
    St15 = _norm(freq_t15).reindex(idx).fillna(0.0)
    St20 = _norm(freq_t20).reindex(idx).fillna(0.0)
    St25 = _norm(freq_t25).reindex(idx).fillna(0.0)
    Sg1    = _norm(freq_g1).reindex(idx).fillna(0.0)
    St15_1 = _norm(freq_t15_1).reindex(idx).fillna(0.0)
    St20_1 = _norm(freq_t20_1).reindex(idx).fillna(0.0)
    St25_1 = _norm(freq_t25_1).reindex(idx).fillna(0.0)

    scored = pd.DataFrame({"valor": idx}).set_index("valor")
    scored["Sg"] = Sg; scored["St15"] = St15; scored["St20"] = St20; scored["St25"] = St25
    scored["Sg1"] = Sg1; scored["St15_1"] = St15_1; scored["St20_1"] = St20_1; scored["St25_1"] = St25_1
    return scored

# ----------------------------- métodos fortes -----------------------------
def gerar_L3_like(scored: pd.DataFrame, k: int = 25) -> List[int]:
    s = 0.6*scored["St20"] + 0.4*scored["Sg"]
    df = s.to_frame("score"); df["valor"] = df.index
    return (df.query("valor>=32 and valor<=64")
              .sort_values("score", ascending=False)
              .head(k)["valor"].astype(int).tolist())

def gerar_L9_like(scored: pd.DataFrame, k_mid: int = 18, k_high: int = 7,
                  predict_params: Optional[Dict[str, float]] = None) -> List[int]:
    """
    L9 com ajuste pelos parâmetros da planilha sem base:
    - Se linhas_faltantes==1 -> mantém pesos fortes nas versões _1 (LF=1).
    - Se linhas_faltantes!=1 -> desloca peso para St20/Sg (globais).
    - %faltante alto (>10%) -> aumenta quota 'high' (80–99) em +2, reduz mid -2.
    """
    lf1 = (predict_params or {}).get("linhas_faltantes", 1) == 1
    pct_f = (predict_params or {}).get("pct_faltante", 0.0) or 0.0

    # pesos
    if lf1:
        s = 0.5*scored["St20_1"] + 0.2*scored["Sg1"] + 0.2*scored["St20"] + 0.1*scored["Sg"]
    else:
        s = 0.45*scored["St20"] + 0.25*scored["Sg"] + 0.2*scored["St25"] + 0.1*scored["St15"]

    df = s.to_frame("score"); df["valor"] = df.index

    # quotas base
    k_mid, k_high = 18, 7
    if pct_f > 10.0:
        k_high += 2; k_mid -= 2  # mais “high” quando %faltante alto

    mid  = (df.query("valor>=32 and valor<=64").sort_values("score", ascending=False)
              .head(k_mid)["valor"].astype(int).tolist())
    high = (df.query("valor>=80 and valor<=99").sort_values("score", ascending=False)
              .head(k_high)["valor"].astype(int).tolist())
    return mid + high

def gerar_L9SEQ(step: int = 3,
                start1: int = 32, end1: int = 74,
                start2: int = 37, end2: int = 64,
                k: int = 25) -> List[int]:
    """Duas PAs na faixa média (a que te deu 9/25)."""
    seq1 = list(range(start1, end1+1, step))
    seq2 = list(range(start2, end2+1, step))
    seq = seq1 + seq2
    return seq[:k]

# ----------------------------- CLI -----------------------------
def main():
    parser = argparse.ArgumentParser(description="Gera 25 números a partir de treino prévio; usa a planilha sem base para ajustar pesos/quotas.")
    parser.add_argument("predict", help="Caminho da planilha SEM número-base.")
    parser.add_argument("--train_glob", default="ordenada_extracted/ordenado*.xlsx",
                        help="Glob das planilhas COM número-base.")
    parser.add_argument("--metodo", choices=["L9","L3","L9SEQ"], default="L9",
                        help="L9 (padrão), L3 (mid-only) ou L9SEQ (duas PAs 32–74/37–64).")
    # L9/L3 params
    parser.add_argument("--k_mid", type=int, default=18)
    parser.add_argument("--k_high", type=int, default=7)
    parser.add_argument("--k_l3", type=int, default=25)
    # L9SEQ params
    parser.add_argument("--step", type=int, default=3)
    parser.add_argument("--start1", type=int, default=32)
    parser.add_argument("--end1", type=int, default=74)
    parser.add_argument("--start2", type=int, default=37)
    parser.add_argument("--end2", type=int, default=64)
    args = parser.parse_args()

    # Ler planilha sem base para extrair parâmetros
    df_pred = read_sheet(args.predict)
    pred_params = parse_parameters(df_pred)

    if args.metodo == "L9SEQ":
        lista = gerar_L9SEQ(args.step, args.start1, args.end1, args.start2, args.end2, k=25)
    else:
        base_df = build_base_dataframe(args.train_glob)
        scored = score_numbers(base_df)
        if args.metodo == "L9":
            lista = gerar_L9_like(scored, k_mid=args.k_mid, k_high=args.k_high, predict_params=pred_params)
        else:
            lista = gerar_L3_like(scored, k=args.k_l3)

    print(f"\n=== {args.metodo} para: {args.predict} ===")
    print(lista)

if __name__ == "__main__":
    main()
