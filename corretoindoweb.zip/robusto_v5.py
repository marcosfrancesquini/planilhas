import argparse
import pandas as pd
import joblib
import numpy as np

# --- funções utilitárias ---
def align_features(df, feature_names):
    """Garante que o DataFrame tem as colunas corretas na mesma ordem do treino"""
    X = pd.DataFrame()
    for f in feature_names:
        if f in df.columns:
            X[f] = pd.to_numeric(df[f], errors="coerce")
        else:
            X[f] = 0
    return X[feature_names]

def compute_scores_per_value(model, features, df_num, numero_col="numero"):
    """Calcula score por valor possível (0-99)"""
    scores = {}
    for n in range(100):
        df_num[numero_col] = n
        X = align_features(df_num, features)
        raw = model.predict_proba(X)[:, 1]
        scores[n] = float(np.mean(raw))
    return scores

def run(predict_path, model_path, topk, preset, numero_col=None,
        low_cap=None, mid_cap=None, high_min=None,
        neighbor_penalty=None, neighbor_radius=None):
    # --- carrega modelo ---
    bundle = joblib.load(model_path)
    if isinstance(bundle, dict):
        model = bundle.get("model", None)
        features = bundle.get("features", None)
    else:
        model = bundle
        features = getattr(model, "feature_names_in_", None)

    if model is None or features is None:
        raise ValueError("Modelo inválido ou sem features.")

    # --- carrega dados ---
    df_raw = pd.read_excel(predict_path)
    df_num = df_raw.copy()
    for c in df_num.columns:
        df_num[c] = pd.to_numeric(df_num[c], errors="coerce")

    if numero_col is None:
        numero_col = "numero"
    if numero_col not in df_num.columns:
        df_num[numero_col] = 0

    # --- calcula scores ---
    scores = compute_scores_per_value(model, features, df_num, numero_col)

    # --- aplica preset ---
    arr = np.array(list(scores.items()))
    df_out = pd.DataFrame(arr, columns=["numero", "score"]).sort_values("score", ascending=False)

    # ajustes opcionais
    if low_cap:
        df_out.loc[df_out["numero"] < 10, "score"] *= 1.05
    if mid_cap:
        df_out.loc[(df_out["numero"] >= 10) & (df_out["numero"] < 30), "score"] *= 1.05
    if high_min:
        df_out.loc[df_out["numero"] >= high_min, "score"] *= 1.10
    if neighbor_penalty and neighbor_radius:
        for n in df_out["numero"]:
            mask = df_out["numero"].between(n - neighbor_radius, n + neighbor_radius)
            df_out.loc[mask & (df_out["numero"] != n), "score"] *= (1 - neighbor_penalty)

    # --- resultado final ---
    chosen = df_out.sort_values("score", ascending=False).head(topk)
    print(f">>> {predict_path} [{preset}|top{topk}]:", ", ".join(map(str, chosen["numero"].tolist())))

# --- CLI ---
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predict", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--topk", type=int, required=True)
    ap.add_argument("--preset", required=True)
    ap.add_argument("--numero-col", default=None)
    ap.add_argument("--low-cap", type=int, default=None)
    ap.add_argument("--mid-cap", type=int, default=None)
    ap.add_argument("--high-min", type=int, default=None)
    ap.add_argument("--neighbor-penalty", type=float, default=None)
    ap.add_argument("--neighbor-radius", type=int, default=None)
    args = ap.parse_args()

    run(args.predict, args.model, args.topk, args.preset,
        numero_col=args.numero_col,
        low_cap=args.low_cap,
        mid_cap=args.mid_cap,
        high_min=args.high_min,
        neighbor_penalty=args.neighbor_penalty,
        neighbor_radius=args.neighbor_radius)

if __name__ == "__main__":
    main()
