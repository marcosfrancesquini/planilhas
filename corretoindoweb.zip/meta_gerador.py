#!/usr/bin/env python3
import argparse, re, pandas as pd

PRESETS = {
  "T7_corr":  [1,3,5,7,9,11,13,32,35,38,41,44,47,50,56,59,76,79,82,85,88,91,94,97,99],
  "T11b":     [0,2,5,8,13,29,32,36,39,41,45,47,50,53,56,60,70,73,76,80,82,88,91,94,99],
  "T12b":     [0,4,7,10,11,32,36,38,41,44,47,50,55,58,62,70,73,77,80,83,85,88,92,99],
  "T5":       [0,5,8,11,18,35,38,41,44,47,50,53,56,59,62,71,74,77,80,83,86,91,92,95,97],
  "T11":      [0,2,5,8,11,29,32,35,38,41,44,47,50,53,56,59,70,73,76,79,82,88,91,94,97],
  "T12":      [0,2,5,8,11,32,36,38,42,44,47,50,55,59,61,70,73,76,79,82,85,88,91,99],
  "T13":      [0,2,7,8,12,16,28,29,36,38,41,44,46,55,58,60,62,64,71,77,80,88,92,95,99],
  "T9_corr":  [0,3,5,7,9,11,13,32,38,41,44,47,50,53,56,59,76,79,82,85,88,91,94,95,98],
  "T11a":     [0,2,5,8,11,27,32,35,38,41,44,47,50,53,56,59,70,73,76,79,83,88,91,95,97],
}

def parse_parameters(df):
    text = " ".join([str(x) for x in df.iloc[:3,:12].fillna("").values.ravel().tolist()])
    P = {}
    m = re.search(r"Tamanho do bloco[:\s]*([0-9]+)", text, re.I)
    if m: P["tamanho_bloco"] = int(m.group(1))
    m = re.search(r"(Tamanho do (?:último|ultimo) bloco)[:\s]*([0-9]+)", text, re.I)
    if m: P["ultimo_bloco"] = int(m.group(2))
    m = re.search(r"(%|Porcentagem)\s*Faltante[:\s]*([0-9]+(?:[.,][0-9]+)?)", text, re.I)
    if m: P["pct_faltante"] = float(m.group(2).replace(",", "."))
    m = re.search(r"n[úu]mero de linhas faltantes[:\s]*([0-9]+)", text, re.I)
    if m: P["linhas_faltantes"] = int(m.group(1))
    return P

def choose_by_profile(params, perfil):
    lf = int(params.get("linhas_faltantes", 1) or 1)
    pf = float(params.get("pct_faltante", 0.0) or 0.0)
    if perfil == "clean":
        return ["T11b","T12b","T11","T12"]
    if perfil == "irregular":
        return ["T7_corr","T13","T9_corr","T5"]
    if perfil == "classico":
        return ["T5","T11","T12"]
    if perfil == "turbo10":
        return ["T11b","T7_corr","T12b","T9_corr"]
    # auto por parâmetros
    if lf == 1 and pf <= 8.0:
        return ["T11b","T12b","T11","T12"]
    if pf >= 10.0 or lf >= 2:
        return ["T7_corr","T13","T9_corr","T5"]
    return ["T5","T11b","T12b","T11","T12","T13"]

def main():
    ap = argparse.ArgumentParser(description="Meta-gerador de 25 números (presets campeões).")
    ap.add_argument("planilha", help="Arquivo XLSX (sem número-base).")
    ap.add_argument("--perfil", choices=["auto","clean","irregular","classico","turbo10"], default="auto")
    ap.add_argument("--topk", type=int, default=3, help="Quantas listas sugerir (1..5)")
    args = ap.parse_args()

    df = pd.read_excel(args.planilha, header=None, engine="openpyxl")
    params = parse_parameters(df)
    ordem = choose_by_profile(params, args.perfil)

    print(f"Parâmetros: {params}")
    for tag in ordem[:max(1,min(args.topk,5))]:
        print(f"{tag} = {PRESETS[tag]}")

if __name__ == "__main__":
    main()
