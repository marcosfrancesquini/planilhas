#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, re, unicodedata, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

warnings.filterwarnings("ignore")

def normalize_header(col):
    if not isinstance(col, str):
        col = str(col)
    col = unicodedata.normalize('NFKD', col).encode('ASCII','ignore').decode('ASCII')
    col = re.sub(r'[^A-Za-z0-9]+', '_', col)
    col = re.sub(r'_+', '_', col).strip('_').lower()
    return col

def make_unique(names):
    seen = {}
    out = []
    for n in names:
        base = n
        if base not in seen:
            seen[base] = 0
            out.append(base)
        else:
            seen[base] += 1
            out.append(f"{base}_{seen[base]}")
    return out

def smart_read(path):
    df = pd.read_excel(path, header=0)
    # promove a 1a linha a header se a maioria for Unnamed
    if np.mean([str(c).lower().startswith("unnamed") for c in df.columns]) > 0.5:
        hdr = df.iloc[0].astype(str).tolist()
        df = df.iloc[1:].reset_index(drop=True)
        df.columns = hdr
    # normaliza e garante unicidade
    cols_norm = [normalize_header(c) for c in df.columns]
    cols_norm = make_unique(cols_norm)
    df.columns = cols_norm
    return df

def series_from_maybe_df(obj):
    if hasattr(obj, 'ndim') and obj.ndim == 2:
        return pd.to_numeric(obj.iloc[:,0], errors="coerce")
    return pd.to_numeric(obj, errors="coerce")

def add_positional_features(df_num):
    out = df_num.copy()
    for c in list(out.columns):
        out[c] = series_from_maybe_df(out[c])
    n = max(len(out)-1, 1)
    out["row_idx"] = np.arange(len(out))
    out["row_pos01"] = out["row_idx"] / n
    return out.fillna(0)

def find_numero_candidates(df_num):
    pattern = re.compile(r"^numero(_\d+)?$")
    cand = [c for c in df_num.columns if pattern.match(c)]
    if cand:
        return cand
    scores = []
    for c in df_num.columns:
        s = series_from_maybe_df(df_num[c])
        if s.notna().any():
            frac = (s.dropna().round().between(0,99)).mean()
        else:
            frac = 0.0
        scores.append((frac, c))
    scores.sort(reverse=True)
    return [c for _, c in scores[:3]]

def get_model_and_features(model_path):
    bundle = joblib.load(model_path)
    if isinstance(bundle, dict) and "model" in bundle:
        model = bundle["model"]
        features = list(bundle.get("features", []))
    else:
        model = bundle
        features = list(getattr(model, "feature_names_in_", []))
    return model, features

def build_X(df_num, train_features, model):
    norm_to_actual = {}
    for c in df_num.columns:
        n = normalize_header(c)
        if n not in norm_to_actual:
            norm_to_actual[n] = c

    feats = list(train_features) if train_features else list(df_num.columns)
    cols = {}
    for f in feats:
        nf = normalize_header(f)
        if nf in norm_to_actual:
            col = df_num[norm_to_actual[nf]]
            cols[f] = series_from_maybe_df(col)
        else:
            cols[f] = 0.0

    X = pd.DataFrame(cols, index=df_num.index).fillna(0)

    if hasattr(model, "feature_names_in_") and len(getattr(model,"feature_names_in_"))>0:
        want = list(model.feature_names_in_)
        for w in want:
            if w not in X.columns:
                X[w] = 0.0
        X = X.reindex(columns=want, fill_value=0)
    else:
        X = X.reindex(columns=feats, fill_value=0)

    return X

def compute_scores_per_value(model, train_features, df_num, numero_override=None):
    X = build_X(df_num, train_features, model)
    if hasattr(model, "predict_proba"):
        raw = model.predict_proba(X)[:, 1]
    elif hasattr(model, "decision_function"):
        z = model.decision_function(X)
        raw = (z - z.min())/(z.max()-z.min()+1e-9)
    else:
        raw = model.predict(X).astype(float)

    value_scores = {v: 0.0 for v in range(100)}
    counts = {v: 0 for v in range(100)}

    if numero_override:
        num_cols = [numero_override]
    else:
        num_cols = find_numero_candidates(df_num)

    used = False
    for num_col in num_cols:
        if num_col not in df_num.columns:
            continue
        s = series_from_maybe_df(df_num[num_col]).round().astype("Int64")
        if s.notna().sum() == 0:
            continue
        for i, val in s.items():
            if val is pd.NA:
                continue
            vv = int(val)
            if 0 <= vv <= 99:
                value_scores[vv] += float(raw[i]); counts[vv] += 1
                used = True
        if used:
            break

    if used:
        for v in range(100):
            if counts[v] > 0:
                value_scores[v] /= counts[v]
    else:
        base = np.linspace(0,1,100)
        for v in range(100):
            value_scores[v] = float(base[v])
    return value_scores

PRESETS = {
    "highbias26": {"low_cap": 6, "mid_cap": 10, "high_min": 26, "neighbor_penalty": 0.40, "neighbor_radius": 1},
    "highpush28": {"low_cap": 6, "mid_cap": 10, "high_min": 28, "neighbor_penalty": 0.40, "neighbor_radius": 1},
    "spread":     {"low_cap": 8, "mid_cap": 10, "high_min": 22, "neighbor_penalty": 0.55, "neighbor_radius": 2},
    "combo":      {"low_cap": 6, "mid_cap": 10, "high_min": 26, "neighbor_penalty": 0.50, "neighbor_radius": 2},
}

def select_values(scores, topk, low_cap, mid_cap, high_min, neighbor_penalty, neighbor_radius):
    items = sorted(scores.items(), key=lambda x: (-x[1], x[0]))

    def in_low(v):  return 0 <= v <= 29
    def in_mid(v):  return 30 <= v <= 59
    def in_high(v): return 60 <= v <= 99

    selected = []
    cnt_low = cnt_mid = cnt_high = 0

    for v, s in items:
        if len(selected) >= topk: break
        if in_low(v) and cnt_low >= low_cap:   continue
        if in_mid(v) and cnt_mid >= mid_cap:   continue

        remaining = topk - len(selected)
        need_high = max(0, high_min - cnt_high)
        if need_high >= remaining and not in_high(v):
            continue

        if neighbor_penalty and any(abs(v-u) <= neighbor_radius for u in selected):
            s *= (1.0 - neighbor_penalty)
            if s < 1e-12:
                continue

        selected.append(v)
        if   in_low(v):  cnt_low  += 1
        elif in_mid(v):  cnt_mid  += 1
        else:            cnt_high += 1

    if cnt_high < high_min:
        highs = [v for v,_ in items if v not in selected and in_high(v)]
        for v in highs:
            if len(selected) >= topk: break
            selected.append(v); cnt_high += 1

    if len(selected) < topk:
        for v,_ in items:
            if v not in selected:
                selected.append(v)
            if len(selected) >= topk: break

    selected = sorted(set(int(v) for v in selected))[:topk]
    return selected

def run(predict, model_path, topk, preset,
        low_cap=None, mid_cap=None, high_min=None,
        neighbor_penalty=None, neighbor_radius=None,
        numero_override=None):
    df_raw = smart_read(predict)
    df_num = add_positional_features(df_raw)

    model, train_features = get_model_and_features(model_path)

    cfg = PRESETS[preset].copy()
    if low_cap is not None: cfg["low_cap"] = low_cap
    if mid_cap is not None: cfg["mid_cap"] = mid_cap
    if high_min is not None: cfg["high_min"] = high_min
    if neighbor_penalty is not None: cfg["neighbor_penalty"] = neighbor_penalty
    if neighbor_radius is not None: cfg["neighbor_radius"] = neighbor_radius

    scores = compute_scores_per_value(model, train_features, df_num, numero_override)

    selected = select_values(scores, topk,
                             cfg["low_cap"], cfg["mid_cap"], cfg["high_min"],
                             cfg["neighbor_penalty"], cfg["neighbor_radius"])

    stem = Path(predict).stem
    print(f">>> {stem} [{preset}|top{topk}]: " + ", ".join(map(str, selected)))

    out_dir = Path("out_predict"); out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{stem}_top{topk}_{preset}.csv"
    pd.Series(selected, name="valor").to_csv(out_path, index=False)
    print("[ok] salvo em:", out_path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predict", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--topk", type=int, default=50)
    ap.add_argument("--preset", default="highpush28",
                    choices=["highbias26","highpush28","spread","combo"])
    ap.add_argument("--low-cap", type=int, default=None)
    ap.add_argument("--mid-cap", type=int, default=None)
    ap.add_argument("--high-min", type=int, default=None)
    ap.add_argument("--neighbor-penalty", type=float, default=None)
    ap.add_argument("--neighbor-radius", type=int, default=None)
    ap.add_argument("--numero-col", type=str, default=None)
    args = ap.parse_args()

    run(args.predict, args.model, args.topk, args.preset,
        low_cap=args.low_cap, mid_cap=args.mid_cap, high_min=args.high_min,
        neighbor_penalty=args.neighbor_penalty, neighbor_radius=args.neighbor_radius,
        numero_override=args.numero_col)

if __name__ == "__main__":
    main()
