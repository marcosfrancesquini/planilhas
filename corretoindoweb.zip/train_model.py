#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_model.py
---------------------------------
Treina um modelo leve no formato já usado: dict com
- dec_prior: propensão por decil (1..10)
- col_reliability: força das colunas "úteis"

Como acha os alvos (números base):
1) Tenta detectar colunas cujo nome contenha "numero base" (ou variações) e pega seus valores 0..99.
2) Se não achar, tenta ler uma aba chamada "base" (ou "numeros_base") com uma coluna "valor".
3) Como último recurso, aceita um CSV externo passado via --labels file=arquivo.xlsx:path_para_csv
   onde o CSV tem colunas: arquivo, valor   (arquivo = nome do xlsx; valor = 0..99).

Uso:
  python train_model.py --train plan1.xlsx plan2.xlsx plan3.xlsx --out model_refined.pkl

Avaliação rápida (cross-val leave-one-out por arquivo):
  python train_model.py --train plan1.xlsx plan2.xlsx ... --out model_refined.pkl --eval

Dica: pode misturar várias planilhas. O script normaliza os nomes das colunas
 (acentos, maiúsculas/minúsculas) e desconsidera ruído não numérico.
"""
import argparse, pickle, unicodedata, sys
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np, pandas as pd

def norm_text(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", str(s)) if unicodedata.category(c)!="Mn").lower().strip()

def looks_numeric_0_99(series: pd.Series, thr=0.3) -> bool:
    vals = series.dropna().astype(str).tolist()
    if not vals: return False
    ok = 0
    for x in vals:
        try:
            v = int(float(x.strip())); ok += (0 <= v <= 99)
        except: pass
    return (ok/len(vals)) >= thr

def decile_of_row(i, n):
    if n<=0: return 1
    return int(np.ceil((i+1)/n*10))

BASE_DECIL_WEIGHTS = np.array([1.00, -0.40, 0.10, 0.35, 0.30, 0.30, 0.10, 0.15, 0.60, -0.25], dtype=float)
def normalize01(x: np.ndarray) -> np.ndarray:
    mn, mx = x.min(), x.max()
    return (x-mn)/(mx-mn+1e-9)

def extract_blocks(df: pd.DataFrame):
    """Heurística simples: se a primeira linha parecer cabeçalho 'verbal', usa como header;
       senão, usa header automático. Divide apenas se detectar linhas com 'numero base' ou 'freq' no texto."""
    # normaliza colunas
    df0 = df.copy()
    df0.columns = [norm_text(c) if c is not None else "" for c in df0.columns]
    # sem divisão complexa: retorna uma lista com um único bloco limpo
    return [df0]

def find_base_labels_from_sheet(df_dict: dict):
    """Tenta achar uma aba 'base' ou 'numeros_base' com coluna 'valor' (0..99)."""
    for key in df_dict.keys():
        nk = norm_text(key)
        if nk in ("base","numeros_base","n_base","labels"):
            dfb = df_dict[key]
            for col in dfb.columns:
                if norm_text(col) in ("valor","valores","numero","número","num"):
                    try:
                        vals = pd.to_numeric(dfb[col], errors="coerce").dropna().astype(int)
                        vals = vals[(vals>=0)&(vals<=99)].unique().tolist()
                        if vals: return set(vals)
                    except: pass
    return set()

def find_base_labels_from_columns(df: pd.DataFrame):
    """Procura colunas cujo nome contenha 'numero base' (ou variações) e coleta valores 0..99."""
    base_vals = set()
    for col in df.columns:
        nc = norm_text(col)
        if ("numero base" in nc) or ("número base" in nc) or (("numero" in nc) and ("base" in nc)):
            try:
                vals = pd.to_numeric(df[col], errors="coerce").dropna().astype(int)
                vals = vals[(vals>=0)&(vals<=99)].tolist()
                base_vals.update(vals)
            except: pass
    return base_vals

def find_labels_from_csv_map(labels_map: dict, xlsx_path: Path):
    """labels_map: dict[xlsx_name]->set de valores base"""
    return labels_map.get(xlsx_path.name, set())

def load_labels_map_from_cli(label_args):
    # formato esperado: arquivo=plan.xlsx:path_csv
    amap = {}
    for spec in (label_args or []):
        if "=" not in spec or ":" not in spec: continue
        left, csv_path = spec.split("=",1)
        xlsx_name = left.strip()
        csv_path = Path(csv_path.strip())
        if not csv_path.exists(): continue
        try:
            dfc = pd.read_csv(csv_path)
            # espera colunas: arquivo, valor  (arquivo opcional; se não tiver, assume o nome passado)
            if "valor" in dfc.columns:
                vals = pd.to_numeric(dfc["valor"], errors="coerce").dropna().astype(int)
                vals = set(vals[(vals>=0)&(vals<=99)].tolist())
                amap[xlsx_name] = vals
        except Exception as e:
            print("[warn] não consegui ler CSV de labels:", csv_path, e)
    return amap

def train_one(files, labels_map=None):
    # acumuladores
    dec_counts = Counter()       # quantas vezes base aparece em cada decil
    dec_totals = Counter()       # normalização por decil
    col_hit = Counter()          # coluna -> contagem de acertos (base presente)
    col_tot = Counter()          # coluna -> linhas não nulas

    for f in files:
        fpath = Path(f)
        df_all = pd.read_excel(fpath, sheet_name=None)
        # tenta achar por aba específica
        base_vals = find_base_labels_from_sheet(df_all)
        # senão por colunas
        if not base_vals:
            # usa a primeira aba como "dados"
            df = df_all[list(df_all.keys())[0]]
            base_vals = find_base_labels_from_columns(df)
        # senão tenta labels externos
        if not base_vals and labels_map:
            base_vals = find_labels_from_csv_map(labels_map, fpath)

        if not base_vals:
            print(f"[warn] não encontrei labels em {fpath.name} — ignorando no treino.")
            continue

        # extrai bloco simples e varre
        df = df_all[list(df_all.keys())[0]]
        block = extract_blocks(df)[0]

        # colunas candidatas (numéricas 0..99)
        cols = [c for c in block.columns if looks_numeric_0_99(block[c], thr=0.30)]
        if not cols: cols = block.columns.tolist()

        n = len(block)
        for ridx in range(n):
            dec = decile_of_row(ridx, n)
            row_vals = set()
            for c in cols:
                v = block.iloc[ridx][c]
                try:
                    iv = int(float(str(v).strip()))
                except:
                    continue
                if 0 <= iv <= 99:
                    row_vals.add(iv)
                    col_tot[norm_text(c)] += 1
            # contagem por decil
            dec_totals[dec] += 1
            # se algum valor da linha é base, credita decil e colunas
            if row_vals & base_vals:
                dec_counts[dec] += 1
                for c in cols:
                    if not pd.isna(block.iloc[ridx][c]):
                        col_hit[norm_text(c)] += 1

    # monta dec_prior
    dec_prior = np.zeros(10, dtype=float)
    if sum(dec_totals.values())>0:
        for d in range(1,11):
            h = dec_counts.get(d,0)
            t = dec_totals.get(d,0)
            dec_prior[d-1] = h/(t+1e-9)
        # mistura com pesos base (para suavizar)
        base_w = (BASE_DECIL_WEIGHTS - BASE_DECIL_WEIGHTS.min())
        base_w = base_w / (base_w.max() or 1.0)
        dec_prior = 0.6*dec_prior + 0.4*base_w
        # normaliza 0..1
        dp_min, dp_max = dec_prior.min(), dec_prior.max()
        dec_prior = (dec_prior - dp_min) / (dp_max - dp_min + 1e-9)

    # monta col_reliability (taxa de acerto por presença)
    col_reliability = {}
    for c in col_tot.keys():
        col_reliability[c] = float(col_hit.get(c,0) / (col_tot[c] + 1e-9))

    return {"dec_prior": dec_prior.tolist(), "col_reliability": col_reliability}

def eval_leave_one_out(files, labels_map=None):
    rows = []
    for i in range(len(files)):
        train_files = [f for f in files if f != files[i]]
        test_file = files[i]
        model = train_one(train_files, labels_map=labels_map)
        # aplica no teste com uma previsão simples (padrão do seu pipeline)
        hits = predict_hits(test_file, model, topk=50)
        rows.append({"arquivo": Path(test_file).name, "hits_top50": hits})
    return pd.DataFrame(rows)

def predict_hits(xlsx, model_dict, topk=50):
    # aplica um scoring bem próximo do seu v6 (sem vizinhança)
    df_all = pd.read_excel(xlsx, sheet_name=None)
    df = df_all[list(df_all.keys())[0]]
    block = df.copy()
    # extrai labels reais (se existirem) para medir acerto
    base_vals = find_base_labels_from_sheet(df_all)
    if not base_vals:
        base_vals = find_base_labels_from_columns(df)
    if not base_vals:
        return np.nan  # sem rótulo, não dá pra medir

    dec_prior = np.array(model_dict["dec_prior"], dtype=float)
    col_rel = {k: float(v) for k, v in model_dict["col_reliability"].items()}

    # colunas úteis
    cols = [c for c in block.columns if looks_numeric_0_99(block[c], thr=0.30)]
    if not cols: cols = block.columns.tolist()

    # score simples
    from collections import defaultdict
    scores = defaultdict(float)
    w_norm = normalize01(np.array([1.00, -0.40, 0.10, 0.35, 0.30, 0.30, 0.10, 0.15, 0.60, -0.25], dtype=float))
    n = len(block)
    for ridx in range(n):
        dec = decile_of_row(ridx, n) - 1
        base_line = float(dec_prior[dec] * w_norm[dec])
        present_boost = 0.0
        for c in cols:
            if norm_text(c) in col_rel and not pd.isna(block.iloc[ridx][c]):
                present_boost += col_rel[norm_text(c)]
        row_score = base_line * (1.0 + 0.6*present_boost)
        for c in cols:
            v = block.iloc[ridx][c]
            try:
                iv = int(float(str(v).strip()))
            except:
                continue
            if 0 <= iv <= 99:
                scores[iv] += row_score + 0.02

    # topk
    items = sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))
    pred = [v for v,_ in items[:topk]]
    return len(set(pred) & set(base_vals))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", nargs="+", required=True, help="Arquivos .xlsx de treino (pode listar vários)")
    ap.add_argument("--out", default="model_refined.pkl", help="Arquivo do modelo de saída")
    ap.add_argument("--labels", nargs="*", help="Mapeamentos CSV opcionais: plan.xlsx=path.csv")
    ap.add_argument("--eval", action="store_true", help="Faz leave-one-out por arquivo e imprime hits top50")
    args = ap.parse_args()

    labels_map = load_labels_map_from_cli(args.labels)

    model = train_one(args.train, labels_map=labels_map)
    with open(args.out, "wb") as f:
        pickle.dump(model, f)
    print("[ok] modelo salvo em:", args.out)

    if args.eval:
        df_eval = eval_leave_one_out(args.train, labels_map=labels_map)
        print("\n[eval] leave-one-out (hits em top50 por arquivo):")
        print(df_eval.to_string(index=False))

if __name__ == "__main__":
    main()
