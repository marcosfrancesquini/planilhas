#!/usr/bin/env python3
import argparse, re, hashlib, random
from typing import List, Dict, Tuple
from glob import glob
import pandas as pd
import numpy as np

# ------------------ IO & parsing ------------------
def read_sheet(path: str) -> pd.DataFrame:
    return pd.read_excel(path, header=None, engine="openpyxl")

def parse_parameters(df: pd.DataFrame) -> Dict[str, float]:
    text = " ".join([str(x) for x in df.iloc[:3, :12].fillna("").values.ravel().tolist()])
    P: Dict[str, float] = {}
    m = re.search(r"Tamanho do bloco[:\s]*([0-9]+)", text, re.I)
    if m: P["tamanho_bloco"] = int(m.group(1))
    m = re.search(r"(Tamanho do (?:último|ultimo) bloco)[:\s]*([0-9]+)", text, re.I)
    if m: P["ultimo_bloco"] = int(m.group(2))
    m = re.search(r"(%|Porcentagem)\s*Faltante[:\s]*([0-9]+(?:[.,][0-9]+)?)", text, re.I)
    if m: P["pct_faltante"] = float(m.group(2).replace(",", "."))
    m = re.search(r"n[úu]mero de linhas faltantes[:\s]*([0-9]+)", text, re.I)
    if m: P["linhas_faltantes"] = int(m.group(1))
    m = re.search(r"\bK\s*=\s*([0-9]+)", text, re.I)
    if m: P["K"] = int(m.group(1))
    return P

# ------------------ (opcional) score aprendido ------------------
def build_training_scores(train_glob: str) -> Dict[int, float]:
    paths = sorted(glob(train_glob))
    if not paths:
        return {}
    rows = []
    for p in paths:
        df = read_sheet(p)
        # localizar colunas "numero base"
        header_lines = 3
        base_cols = []
        for c in range(df.shape[1]):
            col_text = " ".join([str(x) for x in df.iloc[:header_lines, c].fillna("").tolist()]).lower()
            if "numero base" in col_text or "número base" in col_text:
                base_cols.append(c)
        # início dos dados
        start = 2
        for r in range(0, min(30, len(df))):
            nums = pd.to_numeric(df.iloc[r, :], errors="coerce")
            if np.isfinite(nums).sum() >= 2:
                start = r; break
        # ler valores
        for bc in base_cols:
            ser = pd.to_numeric(df.iloc[start:, bc], errors="coerce")
            pos = 1
            for v in ser:
                if pd.notna(v):
                    try:
                        iv = int(v)
                    except:
                        pos += 1; continue
                    if 1 <= iv <= 99:
                        rows.append({"valor": iv, "pos": pos})
                pos += 1
    if not rows:
        return {}

    base = pd.DataFrame(rows)
    def freq(s): 
        vc = s.value_counts()
        vc.sort_index(inplace=True)
        return vc

    idx = sorted(base["valor"].unique())
    Sg   = freq(base["valor"]).reindex(idx).fillna(0).astype(float)
    St20 = freq(base.query("pos<=20")["valor"]).reindex(idx).fillna(0).astype(float)

    # normaliza 0..1
    def norm(s):
        if len(s)==0: return s
        mx, mn = s.max(), s.min()
        if mx>mn: return (s-mn)/(mx-mn)
        return s/(mx if mx!=0 else 1.0)

    Sg, St20 = norm(Sg), norm(St20)
    score = 0.6*St20 + 0.4*Sg
    return {int(v): float(score.loc[v]) for v in idx}

# ------------------ geradores tipo L9SEQ com adaptação ------------------
def l9seq(start1: int, end1: int, start2: int, end2: int, step: int, k: int=25) -> List[int]:
    s1 = list(range(start1, end1+1, step))
    s2 = list(range(start2, end2+1, step))
    seq = s1 + s2
    # clamp 1..99
    seq = [x for x in seq if 1 <= x <= 99]
    # únicos mantendo ordem
    seen, out = set(), []
    for x in seq:
        if x not in seen:
            out.append(x); seen.add(x)
    return out[:k]

def offsets_from_params(params: Dict[str,float], file_tag: str) -> Tuple[int,int,int]:
    tb = int(params.get("tamanho_bloco", 0) or 0)
    ub = int(params.get("ultimo_bloco", 0) or 0)
    lf = int(params.get("linhas_faltantes", 1) or 1)
    pf = int(round((params.get("pct_faltante", 0.0) or 0.0)*100))
    # usa hash do nome do arquivo para tornar determinístico por planilha
    h = int(hashlib.sha256(file_tag.encode()).hexdigest(), 16)
    rnd = (h % 97)  # 0..96
    o1 = (tb + 2*ub + 3*lf + pf + rnd) % 3
    o2 = (tb + ub + 5*lf + 2*pf + rnd) % 3
    o3 = (2*tb + ub + lf + 3*pf + rnd) % 3
    return o1, o2, o3

def step_from_params(params: Dict[str,float]) -> int:
    # passo mais denso se %faltante>10 ou lf>=2
    pf = params.get("pct_faltante", 0.0) or 0.0
    lf = int(params.get("linhas_faltantes", 1) or 1)
    if pf > 12 or lf >= 3: 
        return 2
    if pf > 8 or lf == 2:
        return 3
    return 4  # mais espaçado quando tudo “limpo”

def make_variant(params: Dict[str,float], file_tag: str, variant: int, k: int=25) -> List[int]:
    # base ranges
    base_start1, base_end1 = 32, 74
    base_start2, base_end2 = 37, 64
    o1, o2, o3 = offsets_from_params(params, file_tag)
    # cada variant gira os offsets diferente
    o = (o1 + variant) % 3
    p = (o2 + 2*variant) % 3
    step = step_from_params(params)  # 2,3 ou 4

    # desloca inícios e também (levemente) os fins
    start1 = base_start1 + o
    start2 = base_start2 + p
    end1   = base_end1 + (1 if (params.get("pct_faltante",0) or 0)>10 else 0) + (1 if (params.get("linhas_faltantes",1) or 1)>=2 else 0)
    end2   = base_end2 + (1 if (params.get("pct_faltante",0) or 0)>12 else 0)

    return l9seq(start1, end1, start2, end2, step=step, k=k)

# ------------------ votação com quotas e desempate esperto ------------------
def pick_with_vote(lists: List[List[int]], train_score: Dict[int,float], file_tag: str,
                   quotas: Tuple[int,int,int]=(12,7,6)) -> List[int]:
    from collections import Counter
    cnt = Counter()
    for L in lists:
        cnt.update(L)

    # função faixa
    def band(x):
        if 32 <= x <= 64: return 0
        if 65 <= x <= 79: return 1
        if 80 <= x <= 99: return 2
        return 3  # fora (evitar)

    # jitter determinístico baseado no arquivo (para empates não cairem sempre no centro)
    rnd_seed = int(hashlib.md5(file_tag.encode()).hexdigest(), 16) % (2**31-1)
    rng = random.Random(rnd_seed)

    # ranking por (freq desc, train_score desc, ruído pequeno, proximidade do centro)
    ranked = sorted(
        cnt.items(),
        key=lambda kv: (
            -kv[1],
            -train_score.get(kv[0], 0.0),
            rng.random(),              # desempate determinístico por arquivo
            abs(kv[0]-53),             # centro levemente deslocado para 53
            kv[0]
        )
    )
    # aplica quotas por faixas
    q_mid, q_hi, q_top = quotas
    out = []
    used = set()
    for v, _ in ranked:
        b = band(v)
        if b == 0 and q_mid>0:
            out.append(v); used.add(v); q_mid -= 1
        elif b == 1 and q_hi>0:
            out.append(v); used.add(v); q_hi -= 1
        elif b == 2 and q_top>0:
            out.append(v); used.add(v); q_top -= 1
        if len(out) == sum(quotas):
            break
    # se sobrar quota por alguma razão, completa pelos próximos (evitando banda 3)
    if len(out) < sum(quotas):
        for v,_ in ranked:
            if v in used: continue
            if 32 <= v <= 99:
                out.append(v)
            if len(out) == sum(quotas):
                break
    return out[:sum(quotas)]

# ------------------ CLI ------------------
def main():
    ap = argparse.ArgumentParser(description="Gera 25 números adaptados à planilha. Usa 3 variações L9SEQ + voto com quotas.")
    ap.add_argument("arquivo", help="Planilha SEM número-base (ex.: ordenado2111.xlsx)")
    ap.add_argument("--train_glob", default="", help="Opcional: glob de planilhas COM número-base para ponderar voto (ex.: ordenada_extracted/ordenado*.xlsx)")
    ap.add_argument("--debug", action="store_true")
    # quotas por faixa (padrão 12 mid, 7 high(65-79), 6 top(80-99))
    ap.add_argument("--q_mid", type=int, default=12)
    ap.add_argument("--q_hi", type=int, default=7)
    ap.add_argument("--q_top", type=int, default=6)
    args = ap.parse_args()

    df = read_sheet(args.arquivo)
    params = parse_parameters(df)
    file_tag = args.arquivo

    # três variações adaptativas
    L0 = make_variant(params, file_tag, variant=0, k=25)
    L1 = make_variant(params, file_tag, variant=1, k=25)
    L2 = make_variant(params, file_tag, variant=2, k=25)

    # score de treino (opcional, melhora desempates)
    train_score = build_training_scores(args.train_glob) if args.train_glob else {}

    final25 = pick_with_vote([L0, L1, L2], train_score, file_tag, quotas=(args.q_mid, args.q_hi, args.q_top))

    print(f"\nArquivo: {args.arquivo}")
    print(f"Parâmetros: {params}\n")
    if args.debug:
        print("L0 =", L0)
        print("L1 =", L1)
        print("L2 =", L2)
        print()
    print("=== Lista final (25) ===")
    print(final25)

if __name__ == "__main__":
    main()
