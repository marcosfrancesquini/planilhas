import argparse
import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier

def load_data(paths):
    dfs = []
    for path in paths:
        df = pd.read_excel(path)
        # normalizar colunas
        cols = [c.strip().lower().replace(" ", "_") for c in df.columns]
        df.columns = cols
        # detectar coluna de rótulo
        label_col = None
        for cand in ["numero_base", "número_base", "numero_base_", "numero_base1", "numero_base_1", "numero_base__1", "numero_base_", "numero_base__", "numero_base"]:
            if cand in cols:
                label_col = cand
                break
        if not label_col and "numero_base" in cols:
            label_col = "numero_base"
        if not label_col:
            raise ValueError(f"Nenhuma coluna 'numero base' encontrada em {path}, colunas: {cols}")
        df = df.dropna(subset=[label_col])
        X = df.drop(columns=[label_col])
        y = df[label_col].astype(int)
        dfs.append((X, y))
    return dfs

def train_model(train_files, model_path):
    dfs = load_data(train_files)
    X_all = pd.concat([X for X, _ in dfs], ignore_index=True)
    y_all = pd.concat([y for _, y in dfs], ignore_index=True)
    model = RandomForestClassifier(n_estimators=300, random_state=42)
    model.fit(X_all, y_all)
    joblib.dump({"model": model, "features": list(X_all.columns)}, model_path)
    print(f"[ok] Modelo salvo em {model_path}")

def predict_numbers(path, model_path, topk, preset,
                    low_cap=0, mid_cap=0, high_min=0,
                    neighbor_penalty=0.0, neighbor_radius=1):
    df = pd.read_excel(path)
    cols = [c.strip().lower().replace(" ", "_") for c in df.columns]
    df.columns = cols
    data = df.copy()
    bundle = joblib.load(model_path)
    model = bundle["model"]
    features = bundle["features"]
    X = data[features].fillna(0)
    # probabilidades
    try:
        probs = model.predict_proba(X)[:, 1]
    except:
        probs = model.predict(X)
    scores = pd.DataFrame({"valor": range(len(probs)), "score": probs})
    scores = scores.groupby("valor")["score"].mean().reset_index()
    # presets
    if preset == "model":
        ranked = scores.sort_values("score", ascending=False)
        return ranked.head(topk)["valor"].tolist()
    # híbrido: distribuir caps
    ranked = scores.sort_values("score", ascending=False)
    low = ranked[ranked["valor"] < 30].head(low_cap)
    mid = ranked[(ranked["valor"] >= 30) & (ranked["valor"] < 70)].head(mid_cap)
    high = ranked[ranked["valor"] >= 70].head(high_min)
    chosen = pd.concat([low, mid, high])
    used = set(chosen["valor"].tolist())
    rest = ranked[~ranked["valor"].isin(used)]
    final = pd.concat([chosen, rest.head(topk - len(chosen))])
    # vizinhança
    if neighbor_penalty > 0:
        vals = final["valor"].tolist()
        penalties = []
        for v in vals:
            pen = sum([1 for u in vals if abs(u - v) <= neighbor_radius and u != v])
            penalties.append(pen)
        final = final.copy()
        final["score"] = final["score"] - neighbor_penalty * np.array(penalties)
        final = final.sort_values("score", ascending=False).head(topk)
    return final.sort_values("valor")["valor"].tolist()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", nargs="*", help="arquivos de treino")
    parser.add_argument("--predict", help="arquivo para prever")
    parser.add_argument("--model", required=True, help="caminho do modelo .pkl")
    parser.add_argument("--topk", type=int, default=50)
    parser.add_argument("--preset", choices=["model", "hybrid", "nobias"], default="hybrid")
    parser.add_argument("--low-cap", type=int, default=0)
    parser.add_argument("--mid-cap", type=int, default=0)
    parser.add_argument("--high-min", type=int, default=0)
    parser.add_argument("--neighbor-penalty", type=float, default=0.0)
    parser.add_argument("--neighbor-radius", type=int, default=1)
    args = parser.parse_args()

    if args.train:
        train_model(args.train, args.model)
    elif args.predict:
        result = predict_numbers(args.predict, args.model, args.topk, args.preset,
                                 args.low_cap, args.mid_cap, args.high_min,
                                 args.neighbor_penalty, args.neighbor_radius)
        print(f">>> {args.predict} [{args.preset}|top{args.topk}]: {', '.join(map(str, result))}")
        outdir = Path("out_predict")
        outdir.mkdir(exist_ok=True)
        outpath = outdir / f"{Path(args.predict).stem}_top{args.topk}_{args.preset}.csv"
        pd.Series(result).to_csv(outpath, index=False)
        print(f"[ok] salvo em: {outpath}")

if __name__ == "__main__":
    main()
