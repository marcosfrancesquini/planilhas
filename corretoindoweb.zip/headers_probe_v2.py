#!/usr/bin/env python3
import sys, pandas as pd, re, unicodedata
from collections import Counter

def norm(s):
    s = unicodedata.normalize('NFKD', str(s)).encode('ASCII','ignore').decode('ASCII')
    s = re.sub(r'[^A-Za-z0-9]+','_', s)
    s = re.sub(r'_+','_', s).strip('_').lower()
    return s

def main(path):
    df = pd.read_excel(path, header=0)
    raw = [str(c) for c in df.columns]
    normed = [norm(c) for c in raw]
    print("Primeiras 30 colunas (raw):", raw[:30])
    print("Primeiras 30 colunas (norm):", normed[:30])
    from collections import Counter
    cnt = Counter(normed)
    dups = [k for k,v in cnt.items() if v>1]
    print("Duplicadas (norm):", dups)
    # tentativa de 'numero'
    best, frac_best = None, 0.0
    for j,c in enumerate(df.columns):
        s = pd.to_numeric(df.iloc[:, j], errors='coerce')
        frac = (s.dropna().round().between(0,99)).mean() if s.notna().any() else 0.0
        if frac > frac_best:
            best, frac_best = c, float(frac)
    print("Sugestao numero_col:", norm(best), "(frac_0..99 =", round(frac_best,3), ")")

if __name__=='__main__':
    main(sys.argv[1])
