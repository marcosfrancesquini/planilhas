
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, re, unicodedata, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

warnings.filterwarnings("ignore")

def normalize_header(col: str) -> str:
    if not isinstance(col, str):
        col = str(col)
    col = unicodedata.normalize('NFKD', col).encode('ASCII','ignore').decode('ASCII')
    col = re.sub(r'[^A-Za-z0-9]+', '_', col)
    col = re.sub(r'_+', '_', col).strip('_').lower()
    return col

def smart_read(path: str) -> pd.DataFrame:
    df = pd.read_excel(path, header=0)
    if np.mean([str(c).lower().startswith("unnamed") for c in df.columns]) > 0.5:
        hdr = df.iloc[0].astype(str).tolist()
        df = df.iloc[1:].reset_index(drop=True)
        df.columns = hdr
    df.columns = [normalize_header(c) for c in df.columns]
    return df

def add_positional_features(df_num: pd.DataFrame) -> pd.DataFrame:
    out = df_num.copy()
    for i in range(out.shape[1]):
        out.iloc[:, i] = pd.to_numeric(out.iloc[:, i], errors="coerce")
    n = max(len(out)-1, 1)
    out["row_idx"] = np.arange(len(out))
    out["row_pos01"] = out["row_idx"] / n
    return out.fillna(0)

PRESETS = {
    "highbias26": {"low_cap": 6, "mid_cap": 10, "high_min": 26, "neighbor_penalty": 0.40, "neighbor_radius": 1},
    "highpush28": {"low_cap": 5, "mid_cap": 9,  "high_min": 28, "neighbor_penalty": 0.40, "neighbor_radius": 1},
    "spread":     {"low_cap": 8, "mid_cap": 10, "high_min": 22, "neighbor_penalty": 0.55, "neighbor_radius": 2},
    "combo":      {"low_cap": 6, "mid_cap": 10, "high_min": 26, "neighbor_penalty": 0.50, "neighbor_radius": 2},
}

def normalize_feature_list(features):
    return [normalize_header(f) for f in features]

def align_features(df_num: pd.DataFrame, features: list) -> pd.DataFrame:
    X = pd.DataFrame(index=df_num.index)
    for f in features:
        if f in df_num.columns:
            col = df_num[f]
            # Se cabeçalho duplicado, df_num[f] vira DataFrame -> pega a primeira coluna
            if isinstance(col, pd.DataFrame):
                s = pd.to_numeric(col.iloc[:, 0], errors="coerce")
            else:
                s = pd.to_numeric(col, errors="coerce")
            X[f] = s
        else:
            X[f] = 0.0
    return X.fillna(0)

def find_numero_column(df_num: pd.DataFrame) -> str|None:
    prefer = [c for c in df_num.columns if re.fullmatch(r"numero(_\d+)?", c)]
    if prefer:
        return prefer[0]
    best, best_frac = None, 0.0
    for i in range(df_num.shape[1]):
        s = pd.to_numeric(df_num.iloc[:, i], errors="coerce")
        if s.notna().sum() == 0: continue
        frac = (s.dropna().round().between(0,99)).mean()
        if frac > best_frac:
            best, best_frac = df_num.columns[i], float(frac)
    return best

def get_model_and_features(model_path: str):
    bundle = joblib.load(model_path)
    if isinstance(bundle, dict) and "model" in bundle:
        model = bundle["model"]
        features = bundle.get("features", [])
    else:
        model = bundle
        features = []
    features = normalize_feature_list(features) if features else []
    return model, features

def compute_scores_per_value(model, features, df_num: pd.DataFrame) -> dict[int, float]:
    if not features:
        features = list(df_num.columns)
    X = align_features(df_num, features)
    if hasattr(model, "predict_proba"):
        raw = model.predict_proba(X)[:, 1]
    elif hasattr(model, "decision_function"):
        z = model.decision_function(X)
        raw = (z - z.min())/(z.max()-z.min()+1e-9)
    else:
        raw = model.predict(X).astype(float)

    value_scores = {v: 0.0 for v in range(100)}
    counts = {v: 0 for v in range(100)}

    num_col = find_numero_column(df_num)
    if num_col is not None:
        s = pd.to_numeric(df_num[num_col], errors="coerce").round().astype("Int64")
        for i, val in s.items():
            if val is pd.NA: continue
            vv = int(val)
            if 0 <= vv <= 99:
                value_scores[vv] += float(raw[i])
                counts[vv] += 1
        for v in range(100):
            if counts[v] > 0:
                value_scores[v] /= counts[v]
    else:
        base = np.linspace(0,1,100)
        for v in range(100):
            value_scores[v] = float(base[v])
    return value_scores

def select_values(scores: dict[int,float], topk: int,
                  low_cap: int, mid_cap: int, high_min: int,
                  neighbor_penalty: float, neighbor_radius: int) -> list[int]:
    items = sorted(scores.items(), key=lambda x: (-x[1], x[0]))

    def in_low(v):  return 0 <= v <= 29
    def in_mid(v):  return 30 <= v <= 59
    def in_high(v): return 60 <= v <= 99

    selected = []
    cnt_low = cnt_mid = cnt_high = 0

    for v, s in items:
        if len(selected) >= topk: break
        if in_low(v) and cnt_low >= low_cap:   continue
        if in_mid(v) and cnt_mid >= mid_cap:   continue
        remaining = topk - len(selected)
        need_high = max(0, high_min - cnt_high)
        if need_high >= remaining and not in_high(v):
            continue
        if neighbor_penalty > 0 and any(abs(v-u) <= neighbor_radius for u in selected):
            s *= (1.0 - neighbor_penalty)
            if s < 1e-12: continue
        selected.append(v)
        if   in_low(v):  cnt_low  += 1
        elif in_mid(v):  cnt_mid  += 1
        else:            cnt_high += 1

    if cnt_high < high_min:
        highs = [v for v,_ in items if v not in selected and in_high(v)]
        for v in highs:
            if len(selected) >= topk: break
            selected.append(v); cnt_high += 1

    if len(selected) < topk:
        for v,_ in items:
            if v not in selected:
                selected.append(v)
            if len(selected) >= topk: break

    return sorted(set(int(v) for v in selected))[:topk]

def run(predict, model_path, topk, preset,
        low_cap=None, mid_cap=None, high_min=None,
        neighbor_penalty=None, neighbor_radius=None):
    df_raw = smart_read(predict)
    df_num = add_positional_features(df_raw)

    model, features = get_model_and_features(model_path)

    cfg = PRESETS[preset].copy()
    if low_cap is not None: cfg["low_cap"] = low_cap
    if mid_cap is not None: cfg["mid_cap"] = mid_cap
    if high_min is not None: cfg["high_min"] = high_min
    if neighbor_penalty is not None: cfg["neighbor_penalty"] = neighbor_penalty
    if neighbor_radius is not None: cfg["neighbor_radius"] = neighbor_radius

    scores = compute_scores_per_value(model, features, df_num)
    selected = select_values(scores, topk,
                             cfg["low_cap"], cfg["mid_cap"], cfg["high_min"],
                             cfg["neighbor_penalty"], cfg["neighbor_radius"])

    stem = Path(predict).stem
    print(f">>> {stem} [{preset}|top{topk}]: " + ", ".join(map(str, selected)))
    out_dir = Path("out_predict"); out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{stem}_top{topk}_{preset}.csv"
    pd.Series(selected, name="valor").to_csv(out_path, index=False)
    print("[ok] salvo em:", out_path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predict", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--topk", type=int, default=50)
    ap.add_argument("--preset", default="highbias26",
                    choices=["highbias26","highpush28","spread","combo"])
    ap.add_argument("--low-cap", type=int, default=None)
    ap.add_argument("--mid-cap", type=int, default=None)
    ap.add_argument("--high-min", type=int, default=None)
    ap.add_argument("--neighbor-penalty", type=float, default=None)
    ap.add_argument("--neighbor-radius", type=int, default=None)
    args = ap.parse_args()

    run(args.predict, args.model, args.topk, args.preset,
        args.low_cap, args.mid_cap, args.high_min,
        args.neighbor_penalty, args_neighbor_radius := args.neighbor_radius)

if __name__ == "__main__":
    main()
